import numpy as np
import math 

extraNumber = 4 * math.pi * pow(10,-7)

def wedge():
    current = input("Current: ")
    current = float(current)
    R1 = input("Input R1: ")
    R2 = input("Input R2: ")
    R1 = float(R1)
    R2 = float(R2)
    theta = input("Theta: ")
    theta = float(theta)
    R1 = R1/100
    R2 = R2/100
    B1 = (extraNumber * current)/(2*R1)
    B2 = (extraNumber * current)/(2*R2)
    newTheta = theta/360
    FinalB = (newTheta*(B1-B2)) * pow(10,6)
    print(FinalB)

wedge()