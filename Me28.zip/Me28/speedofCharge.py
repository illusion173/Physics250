import numpy as np
import math 

extraNumber = 4 * math.pi * pow(10,-7)
def speed():
    charge = input("Input charge: ")
    charge = float(charge)
    charge = charge * pow(10,-6)
    

speed()