import numpy as np
import math

extraNumber = 4 * math.pi * pow(10,-7)

def calcTurns():
    current = input("Input current: ")
    distance = input("Distance: ")
    magneticField = input("Magnetic Field: ")
    current = float(current)
    distance = float(distance)
    magneticField = float(magneticField)
    distance = distance/100
    magneticField = magneticField/1000
    turns = (2*math.pi*distance*magneticField)/(extraNumber*current)
    print(turns)

calcTurns()