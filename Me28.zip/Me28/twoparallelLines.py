import numpy as np
import math 

extraNumber = 4 * math.pi * pow(10,-7)

def findForce():
    current1 = input("Input first Current: ")
    current2 = input("Input second Current: ")
    current1 = float(current1)
    current2 = float(current2)
    length = input("Input Length: ")
    length = float(length)
    distance = input("Input distance between: ")
    distance = float(distance)
    distance = distance/100
    Force = (current1 * current2 * extraNumber * length)/(2*math.pi*distance)
    Force = Force * 1000
    print(Force)
findForce()